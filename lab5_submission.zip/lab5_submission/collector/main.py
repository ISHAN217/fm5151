import json
import os
import requests
import time
from datetime import datetime
import pandas as pd
from alpaca.data import StockHistoricalDataClient, StockBarsRequest, TimeFrame
from typing import Iterable
import schedule
from questdb.ingress import Sender

# Read the config file to get table name, symbols, and lookback days
CONF_PATH = "cfg.json"  # Path to the cfg.json file
with open(CONF_PATH, "r") as f:
    cfg = json.load(f)

# Config variables
table_name = cfg.get("table_name", "daily_history")
symbols = cfg.get("symbols", [])
lookback_days = cfg.get("lookback_days", 30)

QUESTDB_HOST = os.environ.get("QUESTDB_HOST", "localhost")
CONF = f"http::addr={QUESTDB_HOST}:9000;username=admin;password=quest;"

# Alpaca API credentials
ALPACA_API_KEY = os.getenv("PKE014NVBUY6J7V3O17A")
ALPACA_SECRET_KEY = os.getenv("w3ZdoseApsiPJwC1c6QDzNbmP8SMAWWoJ71XLT0e")
alpaca_client = StockHistoricalDataClient(ALPACA_API_KEY, ALPACA_SECRET_KEY)

def init_schema(table_name) -> None:
    """Initializes schema in QuestDB"""
    sql = f"""
    CREATE TABLE IF NOT EXISTS {table_name} (
        symbol SYMBOL,
        open DOUBLE,
        high DOUBLE,
        low DOUBLE,
        close DOUBLE,
        volume DOUBLE,
        trade_count DOUBLE,
        vwap DOUBLE,
        timestamp TIMESTAMP
    ) TIMESTAMP(timestamp) PARTITION BY DAY WAL
    DEDUP UPSERT KEYS(timestamp, symbol);
    """.replace("\n", "")
    result = requests.get(f"http://{QUESTDB_HOST}:9000/exec", params={"query": sql})
    result.raise_for_status()

def collect(symbols: Iterable[str], table_name: str, lookback: int):
    """Inserts symbols into QuestDB for the particular table name starting from
    the lookback period.
    """
    now = datetime.now()
    start = now - pd.tseries.offsets.BDay(lookback)
    print(f"Running collection from {start} to {now}")

    for symbol in symbols:
        # Fetch data from Alpaca for each symbol in the lookback period
        start_date = start.date()
        end_date = now.date()
        request_params = StockBarsRequest(
            symbol_or_symbols=symbol,
            timeframe=TimeFrame.Day,
            start=start_date,
            end=end_date
        )

        bars = alpaca_client.get_stock_bars(request_params)

        # Insert data into QuestDB
        for bar in bars[symbol]:
            query = f"""
                INSERT INTO {table_name} (symbol, open, high, low, close, volume, trade_count, vwap, timestamp)
                VALUES ('{bar.symbol}', {bar.o}, {bar.h}, {bar.l}, {bar.c}, {bar.v}, {bar.t}, {bar.vwap}, '{bar.t}')
            """
            response = requests.get(f"http://{QUESTDB_HOST}:9000/exec", params={"query": query})
            response.raise_for_status()

def main():
    """Entrypoint for collecting data and running periodic updates"""
    init_schema(table_name)  # Initialize schema in QuestDB
    collect(symbols=symbols, table_name=table_name, lookback=lookback_days)  # Collect initial data

    # Schedule daily collection
    schedule.every().day.do(collect, symbols=symbols, table_name=table_name, lookback=lookback_days)

    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    main()
