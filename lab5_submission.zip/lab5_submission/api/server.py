import json
import os
import requests
from typing import Optional
from datetime import datetime
from fastapi import FastAPI
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.historical import StockBarsRequest
from alpaca.data.historical import TimeFrame
from models import Symbols, DailyBar

# Read the config file to get table name and symbols
CONF_PATH = "cfg.json"  # Path to the cfg.json file
with open(CONF_PATH, "r") as f:
    cfg = json.load(f)

QUESTDB_HOST = os.environ.get("QUESTDB_HOST", "localhost")
QUESTDB_ENDPOINT = f"http://{QUESTDB_HOST}:9000/exec"
table_name = cfg.get("table_name", "daily_history")
symbols = cfg.get("symbols", [])

# Alpaca API credentials
ALPACA_API_KEY = os.getenv("PKE014NVBUY6J7V3O17A")
ALPACA_SECRET_KEY = os.getenv("w3ZdoseApsiPJwC1c6QDzNbmP8SMAWWoJ71XLT0e")
alpaca_client = StockHistoricalDataClient(ALPACA_API_KEY, ALPACA_SECRET_KEY)

app = FastAPI()

@app.get("/symbols")
def get_symbols() -> Symbols:
    """Get a list of all symbols available for querying from the database

    Returns:
        Symbols: the available symbols
    """
    # Return the symbols from the configuration file
    return {"symbols": symbols}


@app.get("/daily_bar")
def get_daily_bar(date: str, symbol: Optional[str] = None) -> list[DailyBar]:
    """Get a daily bar for all or a subset of symbols at a particular date

    Args:
        date (str): The specified date of the bar
        symbol (Optional[str], optional): An optional symbol, if not provided will return all bars

    Returns:
        list[DailyBar]: Daily bars at specified date (optionally per symbol)
    """
    # Check if Alpaca is used to fetch the data
    if symbol:
        # Request Alpaca data for a specific symbol
        start_date = datetime.strptime(date, "%Y-%m-%d")
        end_date = start_date

        request_params = StockBarsRequest(
            symbol_or_symbols=symbol,
            timeframe=TimeFrame.Day,
            start=start_date,
            end=end_date
        )

        bars = alpaca_client.get_stock_bars(request_params)
        
        # Map the Alpaca bars to the DailyBar format
        daily_bars = []
        for bar in bars[symbol]:
            daily_bars.append(DailyBar(
                symbol=bar.symbol,
                open=bar.o,
                high=bar.h,
                low=bar.l,
                close=bar.c,
                volume=bar.v,
                trade_count=bar.t,
                vwap=bar.vwap,
                timestamp=bar.t
            ))

        return daily_bars
    else:
        # If symbol is not provided, query QuestDB for the data
        query = f"""
            SELECT * FROM {table_name} WHERE timestamp = '{date}'
        """
        
        # Execute the query on QuestDB
        response = requests.get(QUESTDB_ENDPOINT, params={"query": query})
        response.raise_for_status()

        # Parse the result into the DailyBar format
        data = response.json()["query"]["data"]

        # Prepare the response
        bars = []
        for entry in data:
            bar = DailyBar(
                symbol=entry["symbol"],
                open=entry["open"],
                high=entry["high"],
                low=entry["low"],
                close=entry["close"],
                volume=entry["volume"],
                trade_count=entry["trade_count"],
                vwap=entry["vwap"],
                timestamp=entry["timestamp"]
            )
            bars.append(bar)

        return bars
