from abc import ABC, abstractmethod

import pandas as pd

from .portfolio import Portfolio
from .event import Event


import backtrader as bt
import numpy as np

class AlternateBuySell(bt.Strategy):
    def __init__(self):
        self.buy_turn = True

    def next(self):
        if self.buy_turn:
            self.buy(size=1)
        else:
            self.sell(size=1)
        self.buy_turn = not self.buy_turn

class LowVolStrategy(bt.Strategy):
    def __init__(self):
        self.vols = {}
        self.target_data = None

    def prenext(self):
        for data in self.datas:
            if len(data) > 1:
                returns = np.log(data.close.get(ago=-1, size=len(data) - 1) /
                                 data.close.get(ago=-2, size=len(data) - 1))
                self.vols[data._name] = np.std(returns)

        if self.vols:
            min_vol_symbol = min(self.vols, key=self.vols.get)
            self.target_data = [d for d in self.datas if d._name == min_vol_symbol][0]

    def next(self):
        if self.target_data is not None and not self.position:
            self.buy(data=self.target_data, size=1)

class Momentum(bt.Strategy):
    def next(self):
        for data in self.datas:
            if data.close[0] > data.close[-1] > data.close[-2]:
                self.sell(data=data, size=1)
            elif data.close[0] < data.close[-1] < data.close[-2]:
                self.buy(data=data, size=1)
