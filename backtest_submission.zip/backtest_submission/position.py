class Position:
    def __init__(self, symbol, shares, entry_price):
        self.symbol = symbol
        self.shares = shares
        self.entry_price = entry_price

    def update_shares(self, additional_shares):
        self.shares += additional_shares

    def current_value(self, current_price):
        return self.shares * current_price

    def profit_loss(self, current_price):
        return (current_price - self.entry_price) * self.shares

