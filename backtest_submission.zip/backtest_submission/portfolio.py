from typing import Optional

from .event import Event
from .position import Position


class Portfolio:
    def __init__(self, cash):
        self.cash = cash
        self.positions = {}

    def add_position(self, symbol, shares, price):
        if symbol in self.positions:
            self.positions[symbol].update_shares(shares)
        else:
            self.positions[symbol] = Position(symbol, shares, price)
        self.cash -= shares * price

    def remove_position(self, symbol, shares, price):
        if symbol in self.positions:
            pos = self.positions[symbol]
            pos.update_shares(-shares)
            if pos.shares == 0:
                del self.positions[symbol]
            self.cash += shares * price

    def total_value(self, price_data):
        value = self.cash
        for symbol, pos in self.positions.items():
            value += pos.current_value(price_data.get(symbol, 0))
        return value

