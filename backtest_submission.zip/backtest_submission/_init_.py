# backtestlib/__init__.py
import sys
import os

# Add the backtestlib directory to the Python path
sys.path.append('/content/backtestlib')

# Import classes and functions to make them available at the package level
from .backtest import Backtest
from .data import DataProvider, Interval
from .event import Event
from .portfolio import Portfolio
from .strategy.py import Strategy

