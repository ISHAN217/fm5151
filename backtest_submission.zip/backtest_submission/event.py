from dataclasses import dataclass
from datetime import datetime
from typing import Dict

@dataclass
class Event:
    number: int            # Event number, representing a unique identifier
    timestamp: datetime     # Timestamp indicating when the event occurred
    prices: Dict[str, float] # Prices for each symbol, mapping symbol to price

    def get_price(self, symbol: str) -> float:
        """Returns the price for a given symbol if available, otherwise raises an error."""
        try:
            return self.prices[symbol]
        except KeyError:
            raise ValueError(f"Price for symbol '{symbol}' not found in event data.")

    def __post_init__(self):
        """Ensure all prices are valid float values after initialization."""
        for symbol, price in self.prices.items():
            if not isinstance(price, (int, float)):
                raise ValueError(f"Invalid price type for symbol '{symbol}': {price}")
